import streamlit as st
from googletrans import Translator

st.set_page_config(page_title="Free Translator Chatbot")
st.title("🌍 Free Translator Chatbot")

# Languages you want to allow
LANGUAGES = {
    "English": "en",
    "Urdu": "ur",
    "French": "fr",
    "German": "de",
    "Spanish": "es",
    "Chinese": "zh-cn",
    "Arabic": "ar",
    "Hindi": "hi",
    "Turkish": "tr",
    "Russian": "ru",
    "Japanese": "ja",
    "Korean": "ko"
}

translator = Translator()

# Input
text = st.text_input("Enter your text:")
target = st.selectbox("Translate to:", list(LANGUAGES.keys()))

if st.button("Translate"):
    if text.strip() == "":
        st.warning("Please enter text.")
    else:
        translated = translator.translate(text, dest=LANGUAGES[target])
        st.success(f"**Translated Text:** {translated.text}")
